import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import SearchResults from '../components/search/dataGrid/searchResults';
import {onSearch, onPageNag} from '../actions/searchAction';


const mapStateToProps = state => {
    return {
        searchResult: state.searchReducer.searchResults,
        pageCount: state.searchReducer.pageCount? state.searchReducer.pageCount : 1,
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        onSearch: (filterData) => dispatch(onSearch(filterData)),
        onPageNag: (pageNav) => dispatch(onPageNag(pageNav)),

        

    }
}

const SearchResultsContainer = connect(mapStateToProps, mapDispatchToProps)(SearchResults);
export default SearchResultsContainer;