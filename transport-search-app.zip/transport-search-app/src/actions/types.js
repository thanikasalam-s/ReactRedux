export const GET_SEARCH_RESULTS = 'GET_SEARCH_RESULTS';
export const CLEAR_SEARCH = 'CLEAR_SEARCH';
export const PAGE_NAV = 'PAGE_NAV';