import * as actionTypes from './types';
export const onSearch = (filterData) => {
    return (dispatch, getState) => {
        const { searchReducer } = getState();
        const { size, page } = searchReducer;

        const startindex = (page - 1) * size;
        const endindex = page * size;

        let filterRows = mockData;
        for (var key in filterData) {
            if (filterData[key]) {
                filterRows = filterRows.filter(x => x[key].toLowerCase().includes(filterData[key].toLowerCase()));
            }
        }

  
        const floatingPointPart = (filterRows.length / size) % 1;
        const integerPart = Math.floor(filterRows.length / size);
        let pageCount = isFloat(floatingPointPart) ? integerPart + 1 : integerPart;

        dispatch({
            type: actionTypes.GET_SEARCH_RESULTS,
            payload: { results: filterRows.slice(startindex, endindex), filters: filterData, pageCount:pageCount }
        })
    }
}
function isFloat(n) {
    return Number(n) === n && n % 1 !== 0;
}
export const onPageNag = (pageNav) => {
    return (dispatch, getState) => {
        const { searchReducer } = getState();
        const { searchFilters } = searchReducer;

        const startindex = (pageNav.page - 1) * pageNav.size;
        const endindex = pageNav.page * pageNav.size;


        let filterRows = mockData;
        for (var key in searchFilters) {
            if (searchFilters[key]) {
                filterRows = filterRows.filter(x => x[key].toLowerCase().includes(searchFilters[key].toLowerCase()));
            }
        }

        
        const floatingPointPart = (filterRows.length / pageNav.size) % 1;
        const integerPart = Math.floor(filterRows.length / pageNav.size);
        let pageCount = isFloat(floatingPointPart) ? integerPart + 1 : integerPart;

        dispatch({
            type: actionTypes.PAGE_NAV,
            payload: { results: filterRows.slice(startindex, endindex), size: pageNav.size, page: pageNav.page, pageCount:pageCount }
        })       
    }
}



const mockData = [
    { busNo: "TN01AB1234", from: "Chennai", to: "Coimbatore" },
    { busNo: "TN01CD5678", from: "Coimbatore", to: "Chennai" },
    { busNo: "TN02CD9012", from: "Theni", to: "Chennai" },
    { busNo: "TN02CD3456", from: "Cuddalore", to: "Chennai" },
    { busNo: "TN02CD7890", to: "Theni", from: "Chennai" },
    { busNo: "TN03CD1234", to: "Cuddalore", from: "Chennai" },
    { busNo: "TN03EF5678", from: "Theni", to: "Coimbatore" },
    { busNo: "TN04EF9012", from: "Cuddalore", to: "Coimbatore" },
    { busNo: "TN04GH3456", to: "Theni", from: "Coimbatore" },
    { busNo: "TN05GH7890", to: "Cuddalore", from: "Coimbatore" },

]