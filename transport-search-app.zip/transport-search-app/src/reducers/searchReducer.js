import * as actionTyps from '../actions/types';
const INITIAL_STATE = {
    searchFilters: [],
    searchResults: [],
    pageCount: 1,
    size: "5",
    page: "1"
}

function SearchReducer(state = INITIAL_STATE, action) {
    switch (action.type) {
        case actionTyps.PAGE_NAV: {

            return {
                ...state,
                searchResults: action.payload.results,
                pageCount:action.payload.pageCount,
                size: action.payload.size,
                page: action.payload.page
            }

        }
        case actionTyps.CLEAR_SEARCH: {
            return {
                ...state,
                searchResults: [],
                searchFilters: [],
                pageCount: 1,
                size: "5",
                page: "1"
            }

        }
        case actionTyps.GET_SEARCH_RESULTS: {           

            return {
                ...state,
                searchResults: action.payload.results,
                searchFilters: action.payload.filters,
                pageCount: action.payload.pageCount,
            }
        }
        default:
            return state;
    }
}
export { SearchReducer as default, INITIAL_STATE }