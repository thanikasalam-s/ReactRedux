
import React from 'react';

function ContactPage() {
    return (
       
            <div>
            Contact Page          
            </div>
       
        )
}
export default ContactPage;