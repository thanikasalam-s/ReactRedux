import React, { Component } from 'react';

class CTextBox extends Component {

    constructor(props) {
        super(props);
    }

    render() {
        return (<div className="form-group">
            <label >{this.props.name}</label>
            <input type="text"
                className="form-control"
                key={this.props.keyID}
                name={this.props.keyID}                
                />
        </div>)
    }

}

export default CTextBox;