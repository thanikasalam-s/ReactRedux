import React, { Component } from 'react';

class DataGrid extends Component {

    constructor(props) {
        super(props);
    }

    renderTableHeader() {
        return this.props.colHeader && this.props.colHeader.map((col) => {
            return <th key={col}>{col}</th>
        })
    }
    renderTableResult() {
        return this.props.dataSource && this.props.dataSource.map((col, index) => {
            return <tr key={index}>
                <td>{col.busNo}</td>
                <td>{col.from}</td>
                <td>{col.to}</td>
            </tr>
        })
    }

    render() {
        return (<div>
            <table className="table" key={this.props.keyID}>
                <thead>
                    <tr>{this.renderTableHeader()}</tr>
                </thead>
                <tbody>
                    {this.renderTableResult()}
                </tbody>
            </table>
        </div>)
    }

}

export default DataGrid;