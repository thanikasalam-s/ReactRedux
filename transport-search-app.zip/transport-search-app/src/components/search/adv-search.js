import React, { Component } from 'react';

import CDropDown from '../common/dropDown';
import CTextBox from '../common/textBox';

class AdvSearch extends Component {

    constructor(props) {
        super(props);

        this.state = {
            searchData: this.props.searchFilters
        }
    }


    formHandleChange(event) {
        let _searchData = { ...this.state.searchData };
        _searchData[event.target.name] = event.target.value;
        this.setState({ searchData: _searchData });
        this.props.onSearch(_searchData);        
    }

    render() {
        const destination = [{ displayText: "", value: null },
        { displayText: "Chennai", value: "chennai" },
        { displayText: "Coimbatore", value: "coimbatore" },
        { displayText: "Theni", value: "theni" },
        { displayText: "Cuddalore", value: "cuddalore" },
    ];

        return (<div className="col-sm-12">
            <h4>Search Filters</h4>
            <form onChange={(e) => this.formHandleChange(e)}>
                <div className="row">
                    <div className="col-sm-3">
                        <CTextBox name="Bus Number" keyID="busNo" />
                    </div>
                    <div className="col-sm-3">
                        <CDropDown name="From" keyID="from" dataSource={destination} />
                    </div>
                    <div className="col-sm-3">
                        <CDropDown name="To" keyID="to" dataSource={destination} />
                    </div>                   
                </div>  </form>


        </div>)
    }

}

export default AdvSearch;