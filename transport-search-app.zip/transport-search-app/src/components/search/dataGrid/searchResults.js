import React, { Component } from 'react';
import DataGrid from '../../common/dataGrid';
import CDropDown from '../../common/dropDown';
class SearchResults extends Component {

    constructor(props) {
        super(props);
        this.state = {
            rows: this.props.searchResult,
            pageNav: {
                size: "5",
                page: "1"
            }
        }
    }

    componentWillReceiveProps(nextProps) {
        this.setState({ rows: nextProps.searchResult });
    }

    componentDidMount() {
        this.props.onSearch(null)
    }

    formHandleChange(event) {
        let _pageNav = { ...this.state.pageNav };
        _pageNav[event.target.name] = event.target.value;
        this.setState({ pageNav: _pageNav });
        this.props.onPageNag(_pageNav);
    }

    render() {
        const sizes = [{ displayText: "5", value: "5" },
        { displayText: "10", value: "10" },
        { displayText: "20", value: "20" },
        { displayText: "50", value: "50" },
        { displayText: "100", value: "100" },
        ];

        let pages = []
        for(let i=1; i<=this.props.pageCount; i++){
            pages.push( { displayText: i, value: i });
        }
        //     { displayText: "1", value: "1" },
        //     { displayText: "2", value: "2" },
        //     { displayText: "3", value: "3" },
        // ];
        const header = ["Bus No", "From", "To"]
        return (<div className="col-md-12">
            <h4>Search results</h4>
            <form onChange={(e) => this.formHandleChange(e)}>
                <DataGrid keyID="searchResult"
                    colHeader={header}
                    dataSource={this.state.rows}
                />
                <div className="row">
                    <div className="col-sm-3">
                        <CDropDown keyID="size" dataSource={sizes} />
                    </div>
                    <div className="col-sm-3">
                        <CDropDown keyID="page" dataSource={pages} />
                    </div>
                </div>
            </form>
        </div>)
    }

}

export default SearchResults;