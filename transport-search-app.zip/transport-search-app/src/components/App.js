import React, { Component } from 'react';
// import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import AppHeader from './header';
import AdvSearch from './search/adv-search';
import SearchResults from './search/dataGrid/searchResults';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

import SearchResultsContainer from '../containers/searchResultsContainer';
import SearchFiltersContainer from '../containers/searchFiltersContainer';
import SearchPage from './search';
import AboutPage from './about';
import ContactPage from './contact';

class App extends Component {



  render() {
    return (
      <div className="container-fluid">
        <Router>
          <div className="row justify-content-center">
            <AppHeader />
          </div>
          <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <ul className="navbar-nav mr-auto">
              <li><Link to={'/'} className="nav-link"> Search </Link></li>
              <li><Link to={'/contact'} className="nav-link">Contact</Link></li>
              <li><Link to={'/about'} className="nav-link">About</Link></li>
            </ul>
          </nav>
          <hr />
          <div className="row">
            <Switch>
              <Route exact path='/' component={SearchPage} />
              <Route exact path='/about' component={AboutPage} />
              <Route exact path='/contact' component={ContactPage} />
            </Switch>
          </div>

        </Router>
      </div>
    );
  }
}

export default App;
