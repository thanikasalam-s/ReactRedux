import React from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import SearchPage from './search';

function AboutPage() {
    return (
       
            <div>
            About page            
            </div>
       
        )
}
export default AboutPage;