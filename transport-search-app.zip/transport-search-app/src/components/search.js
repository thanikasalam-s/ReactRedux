import React, { Component } from 'react';
// import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import SearchResultsContainer from '../containers/searchResultsContainer';
import SearchFiltersContainer from '../containers/searchFiltersContainer';

class SearchPage extends Component {
    render() {
        return (
            <div>
                <div className="row">
                    <SearchFiltersContainer />
                </div>
                <div className="row">
                    <SearchResultsContainer />
                </div>
            </div>
        );
    }
}

export default SearchPage;
